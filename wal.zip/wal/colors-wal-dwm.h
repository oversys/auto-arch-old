static const char norm_fg[] = "#9fc6d6";
static const char norm_bg[] = "#010016";
static const char norm_border[] = "#6f8a95";

static const char sel_fg[] = "#9fc6d6";
static const char sel_bg[] = "#E84F66";
static const char sel_border[] = "#9fc6d6";

static const char urg_fg[] = "#9fc6d6";
static const char urg_bg[] = "#C33F64";
static const char urg_border[] = "#C33F64";

static const char *colors[][3]      = {
    /*               fg           bg         border                         */
    [SchemeNorm] = { norm_fg,     norm_bg,   norm_border }, // unfocused wins
    [SchemeSel]  = { sel_fg,      sel_bg,    sel_border },  // the focused win
    [SchemeUrg] =  { urg_fg,      urg_bg,    urg_border },
};
