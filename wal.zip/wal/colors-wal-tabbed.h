static const char* selbgcolor   = "#010016";
static const char* selfgcolor   = "#9fc6d6";
static const char* normbgcolor  = "#E84F66";
static const char* normfgcolor  = "#9fc6d6";
static const char* urgbgcolor   = "#C33F64";
static const char* urgfgcolor   = "#9fc6d6";
