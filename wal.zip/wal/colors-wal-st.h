const char *colorname[] = {

  /* 8 normal colors */
  [0] = "#010016", /* black   */
  [1] = "#C33F64", /* red     */
  [2] = "#E84F66", /* green   */
  [3] = "#FD6E67", /* yellow  */
  [4] = "#FD956B", /* blue    */
  [5] = "#FBDB76", /* magenta */
  [6] = "#27489B", /* cyan    */
  [7] = "#9fc6d6", /* white   */

  /* 8 bright colors */
  [8]  = "#6f8a95",  /* black   */
  [9]  = "#C33F64",  /* red     */
  [10] = "#E84F66", /* green   */
  [11] = "#FD6E67", /* yellow  */
  [12] = "#FD956B", /* blue    */
  [13] = "#FBDB76", /* magenta */
  [14] = "#27489B", /* cyan    */
  [15] = "#9fc6d6", /* white   */

  /* special colors */
  [256] = "#010016", /* background */
  [257] = "#9fc6d6", /* foreground */
  [258] = "#9fc6d6",     /* cursor */
};

/* Default colors (colorname index)
 * foreground, background, cursor */
 unsigned int defaultbg = 0;
 unsigned int defaultfg = 257;
 unsigned int defaultcs = 258;
 unsigned int defaultrcs= 258;
