static const char *colors[SchemeLast][2] = {
	/*     fg         bg       */
	[SchemeNorm] = { "#9fc6d6", "#010016" },
	[SchemeSel] = { "#9fc6d6", "#C33F64" },
	[SchemeOut] = { "#9fc6d6", "#27489B" },
};
