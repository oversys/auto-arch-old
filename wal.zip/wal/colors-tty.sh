#!/bin/sh
[ "${TERM:-none}" = "linux" ] && \
    printf '%b' '\e]P0010016
                 \e]P1C33F64
                 \e]P2E84F66
                 \e]P3FD6E67
                 \e]P4FD956B
                 \e]P5FBDB76
                 \e]P627489B
                 \e]P79fc6d6
                 \e]P86f8a95
                 \e]P9C33F64
                 \e]PAE84F66
                 \e]PBFD6E67
                 \e]PCFD956B
                 \e]PDFBDB76
                 \e]PE27489B
                 \e]PF9fc6d6
                 \ec'
